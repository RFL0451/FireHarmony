FireHarmony - open index.html in any browser (double-click). No install, no server.

Pages:  index.html (Overview)  |  dashboard.html (Dashboard)
Needs an internet connection for map tiles, Leaflet, Chart.js and the Inter font.
Data:   js/mock-data.js holds synthetic demo detections (not real fires).
Edit:   replace the GitHub URL, team names and email in index.html (slide 8) before presenting.
Tip:    on the Overview page use arrow keys / PageUp/PageDown to move between slides.
