import 'dotenv/config';
import express from 'express';
import path from 'node:path';                              
import { fileURLToPath } from 'node:url';                    
import { fetchFirms } from './firms.js';
import { normalize } from './normalize.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url)); 
const app = express();
const PORT = process.env.PORT || 3000;

// CORS для локальной разработки фронтенда
app.use((req, res, next) => { res.setHeader('Access-Control-Allow-Origin', '*'); next(); });

app.get('/api/hotspots', async (req, res) => {
  try {
    const { bbox, dateFrom, dateTo, sensors = 'MODIS,VIIRS' } = req.query;
    if (!bbox || !dateFrom || !dateTo) return res.status(400).json({ error: 'bbox, dateFrom, dateTo required' });
    const [w, s, e, n] = bbox.split(',').map(Number);
    if ([w, s, e, n].some(x => !Number.isFinite(x))) return res.status(400).json({ error: 'bad bbox' });

    const sources = { MODIS: 'MODIS_NRT', VIIRS: 'VIIRS_SNPP_NRT' };
    const list = String(sensors).split(',').map(x => x.trim().toUpperCase()).filter(x => sources[x]);
    if (!list.length) return res.status(400).json({ error: 'no valid sensors' });

    let hotspots = [];
    for (const sensor of list) {
      const csv = await fetchFirms({ source: sources[sensor], bbox: [w, s, e, n], dateFrom, dateTo });
      hotspots = hotspots.concat(normalize(csv, sensor));
    }
    const toMs = Date.parse(dateTo) + 86399999;
    hotspots = hotspots.filter(p => p.t >= Date.parse(dateFrom) && p.t <= toMs);

    const days = new Map();
    hotspots.forEach(p => {
      const d = new Date(p.t).toISOString().slice(0, 10);
      const cur = days.get(d) || { date: d, count: 0, sumFrp: 0 };
      cur.count++; cur.sumFrp += p.frp || 0;
      days.set(d, cur);
    });
    const timeline = [...days.values()].sort((a, b) => a.date.localeCompare(b.date));

    res.json({ meta: { count: hotspots.length, source: 'FIRMS' }, hotspots, timeline });
  } catch (e) {
    console.error('[hotspots]', e.message);
    res.status(502).json({ error: e.message });
  }
});

app.use(express.static(path.join(__dirname, '..'), {
  index: 'index.html',
  dotfiles: 'deny',        // не отдавать .env и прочие dotfiles
}));

app.listen(PORT, () => console.log(`App + API on http://localhost:${PORT}`));