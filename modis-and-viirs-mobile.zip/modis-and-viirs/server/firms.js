import { cache } from './cache.js';
const KEY = process.env.FIRMS_MAP_KEY;
const BASE = 'https://firms.modaps.eosdis.nasa.gov/api/area/csv';

export async function fetchFirms({ source, bbox, dateFrom, dateTo }) {
  if (!KEY) throw new Error('FIRMS_MAP_KEY is not set');
  const [w, s, e, n] = bbox;
  const days = Math.min(10, Math.max(1,
    Math.ceil((Date.parse(dateTo) - Date.parse(dateFrom)) / 864e5) + 1));
  const cacheKey = `${source}|${w},${s},${e},${n}|${dateFrom}|${dateTo}`;
  const hit = cache.get(cacheKey);
  if (hit) return hit;

  const url = `${BASE}/${KEY}/${source}/${w},${s},${e},${n}/${days}`;
  const res = await fetch(url);
  if (!res.ok) throw new Error(`FIRMS ${res.status}`);
  const text = await res.text();
  if (text.startsWith('<')) throw new Error('FIRMS returned HTML — bad key or bbox too large');
  cache.set(cacheKey, text);
  return text;
}