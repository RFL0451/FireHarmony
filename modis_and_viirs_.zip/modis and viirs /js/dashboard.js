(() => {
'use strict';
const C = { M: '#D55E00', V: '#0072B2', B: '#E69F00' };
const REGIONS = { World:[-90,-180,90,180], 'North America':[7,-170,72,-50], 'South America':[-56,-82,13,-34], Europe:[35,-25,72,45], Africa:[-35,-20,37,52], Asia:[-10,45,78,180], Oceania:[-50,110,0,180] };
const DAY = 864e5, $ = id => document.getElementById(id);
let raw = [], view = { m: [], v: [], pairs: [] }, charts = {};

// ---- UI helpers
const status = (t, err, busy) => { $('statusText').textContent = t; $('status').className = 'status' + (err ? ' err' : '') + (busy ? ' loading' : ''); };
$('region').innerHTML = Object.keys(REGIONS).map(r => `<option>${r}</option>`).join('');
const iso = d => d.toISOString().slice(0, 10);
const setDates = () => { const n = +$('preset').value; if (!n) return; $('to').value = iso(new Date()); $('from').value = iso(new Date(Date.now() - (n - 1) * DAY)); };
setDates();
$('preset').onchange = setDates;
$('from').onchange = $('to').onchange = () => $('preset').value = 'custom';

// ---- Data loading
function loadDemo() {
  const now = Date.now();
  return window.MOCK_FIRES.records.map(([s, lat, lon, d, bt, c]) => {
    const t = now - d * DAY;
    const hUTC = new Date(t).getUTCHours();
    return {
      s, lat, lon, t, bt, c,
      frp: +((Math.max(0, bt - 290) * 0.15) * (0.4 + c / 100)).toFixed(2),
      sat: s === 'M' ? (d % 2 < 1 ? 'Terra' : 'Aqua') : (d % 2 < 1 ? 'NPP' : 'NOAA-20'),
      inst: s === 'M' ? 'MODIS' : 'VIIRS',
      dn: hUTC >= 6 && hUTC < 18 ? 'D' : 'N',
      persistent: false,
    };
  });
}

// ---- Harmonization
const hav = (a, b) => { const r = Math.PI / 180, dl = (b.lat - a.lat) * r, dn = (b.lon - a.lon) * r; const x = Math.sin(dl/2)**2 + Math.cos(a.lat*r)*Math.cos(b.lat*r)*Math.sin(dn/2)**2; return 12742 * Math.asin(Math.sqrt(x)); };
function harmonize(m, v, maxKm, maxH) {
  const G = .05, key = (la, lo) => Math.floor(la / G) + ':' + Math.floor(lo / G), grid = new Map();
  v.forEach(p => { const k = key(p.lat, p.lon); (grid.get(k) || grid.set(k, []).get(k)).push(p); });
  const used = new Set(), pairs = [];
  m.forEach(a => { let best, bd = 1e9; const gi = Math.floor(a.lat / G), gj = Math.floor(a.lon / G);
    for (let i = -1; i <= 1; i++) for (let j = -1; j <= 1; j++) for (const b of grid.get((gi+i) + ':' + (gj+j)) || []) {
      if (used.has(b) || Math.abs(a.t - b.t) > maxH * 36e5) continue; const d = hav(a, b); if (d <= maxKm && d < bd) { bd = d; best = b; } }
    if (best) { used.add(best); pairs.push({ m: a, v: best }); } });
  return pairs;
}

// ---- Filtering + stats
function filtered() {
  const [s, w, n, e] = REGIONS[$('region').value];
  const from = Date.parse($('from').value + 'T00:00:00Z'), to = Date.parse($('to').value + 'T23:59:59Z');
  const ok = p => p.t >= from && p.t <= to && p.lat >= s && p.lat <= n && p.lon >= w && p.lon <= e;
  const m = raw.filter(p => p.s === 'M' && ok(p)), v = raw.filter(p => p.s === 'V' && ok(p));
  return { m, v, pairs: harmonize(m, v, +$('dist').value, +$('hours').value) };
}
const pct = (a, b) => b ? Math.round(a / b * 1000) / 10 : 0;

// ---- Map
const map = L.map('map', { preferCanvas: true, worldCopyJump: true }).setView([15, 20], 2);
// Base layers double as the label-language switcher:
// CARTO Voyager renders English place names, OSM standard renders local names.
const baseEn = L.tileLayer('https://server.arcgisonline.com/ArcGIS/rest/services/World_Street_Map/MapServer/tile/{z}/{y}/{x}', {
  attribution: 'Tiles &copy; Esri &mdash; Source: Esri, DeLorme, NAVTEQ',
  maxZoom: 19,
}).addTo(map);
const baseLocal = L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
  attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors', maxZoom: 19,
});
const sat = L.tileLayer('https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}', { attribution: 'Esri World Imagery', maxZoom: 18 });
L.control.layers({
  'Map labels: English': baseEn,
  'Map labels: local language': baseLocal,
  'Satellite (no labels)': sat,
}, null, { collapsed: false }).addTo(map);
const cluster = L.markerClusterGroup({ chunkedLoading: true, maxClusterRadius: 45 }).addTo(map);
const lg = L.control({ position: 'bottomright' });
lg.onAdd = () => {
  const d = L.DomUtil.create('div', 'legend');
  d.innerHTML = `<b>Legend</b><br>
    <span class="lg-dot" style="background:${C.M}"></span> MODIS (1 km)<br>
    <span class="lg-dot" style="background:${C.V}"></span> VIIRS (375 m)<br>
    <span class="lg-dot big" style="background:${C.B}"></span> Matched by both sensors<br>
    <span class="lg-ring"></span> Persistent hot spot<br>
    <span class="lg-note">Larger dot = one fire confirmed by two sensors.<br>Ring = recurs on many days, likely a static<br>heat source (flare, volcano), not a wildfire.</span>`;
  L.DomEvent.disableClickPropagation(d);
  return d;
};
lg.addTo(map);
const fmt = t => new Date(t).toISOString().replace('T', ' ').slice(0, 16) + ' UTC';

function marker(p, type) {
  const big = type === 'B', col = C[type];
  const persistent = big ? (p.m.persistent || p.v.persistent) : p.persistent;
  const m = L.circleMarker([p.lat, p.lon], {
    radius: big ? 8 : 5,
    color: persistent ? '#6b6f76' : '#1b2540',
    weight: persistent ? 2.5 : (big ? 2 : .6),
    dashArray: persistent ? '3 2' : null,
    fillColor: col, fillOpacity: persistent ? .45 : .9,
  });
  const confHtml = (pt, matched) => {
    const cf = Confidence.assess(pt, { matched });
    return `<hr><b>Fire likelihood: <span class="cf cf-${cf.cls}">${cf.level}</span> (${cf.score}/100)</b><br>
      <span class="cf-why">${cf.why || ''}</span><br><span class="cf-note">${cf.note}</span>`;
  };
  let h;
  if (big) {
    const dKm = hav(p.m, p.v), dH = (Math.abs(p.m.t - p.v.t) / 36e5).toFixed(2);
    h = `<b>Harmonized (both sensors)</b><br>${fmt(p.m.t)}<br>${p.lat.toFixed(4)}, ${p.lon.toFixed(4)}<br>
      Δ distance: <b>${dKm.toFixed(2)} km</b> · Δ time: <b>${dH} h</b><hr>
      MODIS: FRP ${p.m.frp} MW · BT ${p.m.bt} K · conf ${p.m.c}<br>
      VIIRS: FRP ${p.v.frp} MW · BT ${p.v.bt} K · conf ${p.v.c}` +
      confHtml({ c: Math.max(p.m.c, p.v.c), frp: Math.max(p.m.frp, p.v.frp), persistent }, true);
  } else {
    h = `<b>${type === 'M' ? 'MODIS' : 'VIIRS'}</b>${persistent ? ' · <i>persistent</i>' : ''}<br>
      ${fmt(p.t)}<br>${p.lat.toFixed(4)}, ${p.lon.toFixed(4)}<br>
      Satellite: ${p.sat || '—'} · ${p.dn === 'N' ? 'night' : 'day'}<br>
      FRP: <b>${p.frp} MW</b><br>BT: ${p.bt} K · confidence ${p.c}` +
      confHtml(p, false);
  }
  return m.bindPopup(h);
}
function drawMap() {
  const mode = document.querySelector('[name=sensor]:checked').value, { m, v, pairs } = view;
  const hide = $('hidePersist').checked;
  const pass = p => !hide || !p.persistent;
  const um = new Set(pairs.map(x => x.m)), uv = new Set(pairs.map(x => x.v)), out = [];
  if (mode === 'MODIS') m.filter(pass).forEach(p => out.push(marker(p, 'M')));
  else if (mode === 'VIIRS') v.filter(pass).forEach(p => out.push(marker(p, 'V')));
  else {
    m.filter(p => !um.has(p) && pass(p)).forEach(p => out.push(marker(p, 'M')));
    v.filter(p => !uv.has(p) && pass(p)).forEach(p => out.push(marker(p, 'V')));
    pairs.filter(x => pass(x.m) && pass(x.v)).forEach(x =>
      out.push(marker({ m: x.m, v: x.v, lat: (x.m.lat + x.v.lat) / 2, lon: (x.m.lon + x.v.lon) / 2 }, 'B')));
  }
  cluster.clearLayers(); cluster.addLayers(out);
}

// ---- Charts + text
const grid = 'rgba(11,23,54,.1)', tick = '#46557a';
Chart.defaults.color = tick; Chart.defaults.font.family = 'Inter, sans-serif';
const mk = (id, cfg) => { cfg.options = Object.assign({ responsive: true, maintainAspectRatio: false }, cfg.options); return new Chart($(id), cfg); };
const axes = { x: { grid: { color: grid } }, y: { grid: { color: grid }, beginAtZero: true } };
charts.time = mk('cTime', { type: 'line', data: { labels: [], datasets: [] }, options: { scales: axes, interaction: { mode: 'index', intersect: false } } });
charts.conf = mk('cConf', { type: 'bar', data: { labels: ['0-19', '20-39', '40-59', '60-79', '80-100'], datasets: [] }, options: { scales: axes } });
charts.over = mk('cOver', { type: 'doughnut', data: { labels: ['MODIS only', 'VIIRS only', 'Both'], datasets: [{ data: [], backgroundColor: [C.M, C.V, C.B], borderColor: '#ffffff' }] } });

function rangeDays() {
  const out = []; let t = Date.parse($('from').value + 'T00:00:00Z'); const end = Date.parse($('to').value + 'T00:00:00Z');
  while (t <= end && out.length < 120) { out.push(iso(new Date(t))); t += DAY; } return out;
}
function anomalies(s) {
  const n = s.length, mean = s.reduce((a, b) => a + b, 0) / (n || 1), sd = Math.sqrt(s.reduce((a, b) => a + (b - mean) ** 2, 0) / (n || 1));
  const z = s.map(x => sd ? (x - mean) / sd : 0); return { mean, sd, z, ok: n >= 7, flag: z.map(v => n >= 7 && v >= 2) };
}
function unified() {
  const { m, v, pairs } = view, um = new Set(pairs.map(x => x.m)), uv = new Set(pairs.map(x => x.v));
  return [...pairs.map(x => ({ lat: (x.m.lat + x.v.lat) / 2, lon: (x.m.lon + x.v.lon) / 2, t: x.m.t })), ...m.filter(p => !um.has(p)), ...v.filter(p => !uv.has(p))];
}
function drawAnomalies(days, an) {
  const u = unified(), uni = days.map(d => 0); u.forEach(p => { const i = days.indexOf(iso(new Date(p.t))); if (i >= 0) uni[i]++; });
  const list = days.map((d, i) => an.flag[i] ? `${d} (${uni[i]} hot spots)` : null).filter(Boolean);
  $('anom').textContent = !an.ok ? 'Choose at least 7 days to check for anomalies' : list.length ? 'Anomalous days: ' + list.join(', ') : 'No anomalous days. Activity stays within the normal range for this period and region';
  const rows = Object.entries(REGIONS).filter(([k]) => k !== 'World').map(([name, [s, w, n, e]]) => {
    const pts = u.filter(p => p.lat >= s && p.lat <= n && p.lon >= w && p.lon <= e), ser = days.map(() => 0);
    pts.forEach(p => { const i = days.indexOf(iso(new Date(p.t))); if (i >= 0) ser[i]++; });
    const a = anomalies(ser), pk = ser.indexOf(Math.max(...ser)), alert = a.ok && a.flag[pk] && ser[pk] >= 5;
    return { name, total: pts.length, mean: a.mean, day: days[pk], peak: ser[pk], alert };
  }).filter(r => r.total).sort((a, b) => b.total - a.total).slice(0, 7);
  $('regions').innerHTML = rows.map(r => `<tr><th scope="row">${r.name}</th><td>${r.total}</td><td>${r.mean.toFixed(1)}</td><td>${r.day}</td><td>${r.peak}</td><td>${r.alert ? '<b style="color:#c6613f">Anomalously high</b>' : 'Normal'}</td></tr>`).join('') || '<tr><td colspan="6">No detections</td></tr>';
}

function syncOut() {
  $('distOut').textContent = (+$('dist').value) + ' km';
  $('hoursOut').textContent = $('hours').value + ' h';
  $('persistDaysOut').textContent = $('persistDays').value;
  $('persistKmOut').textContent = (+$('persistKm').value); 
}

function drawStats() {
  const { m, v, pairs } = view, n = pairs.length, uniq = m.length + v.length - n, mo = m.length - n, vo = v.length - n;  
  const inc = pct(uniq - m.length, m.length);
  
  const pctM = pct(n, m.length), pctV = pct(n, v.length);
  $('metrics').innerHTML = [
    [uniq, 'Total unique hot spots (harmonized)'],
    [pct(n, uniq) + '%', 'Seen by both sensors'],
    [mo, 'MODIS-only'],
    [vo, 'VIIRS-only'],
    [pctM + '%', '% of MODIS matched'],
    [pctV + '%', '% of VIIRS matched'],
    ['+' + inc + '%', 'Increase vs MODIS alone'],
  ].map(([a, b]) => `<div class="metric"><b>${a}</b><span>${b}</span></div>`).join('');

  $('summary').textContent = uniq ? `For the selected period and region, MODIS detected ${m.length} hot spots and VIIRS detected ${v.length}. ${n} were detected by both sensors. Harmonization revealed ${inc}% more unique fires than MODIS alone` : 'No detections match these filters. Widen the time range or choose another region';
  const day = t => iso(new Date(t)), days = rangeDays(), idx = new Map(days.map((d, i) => [d, i]));
  const count = arr => { const a = days.map(() => 0); arr.forEach(p => { const i = idx.get(day(p.t)); if (i !== undefined) a[i]++; }); return a; };
  const cm = count(m), cv = count(v), cn = count(pairs.map(x => x.m)), uni = cm.map((x, i) => x + cv[i] - cn[i]), an = anomalies(uni);
  const ds = (l, d, c) => ({ label: l, data: d, borderColor: c, backgroundColor: c, tension: .25, pointRadius: 2 });
  const hd = ds('Harmonized (unique)', uni, C.B); hd.pointRadius = uni.map((_, i) => an.flag[i] ? 7 : 2); hd.pointBackgroundColor = uni.map((_, i) => an.flag[i] ? '#141413' : C.B);
  Object.assign(charts.time.data, { labels: days, datasets: [ds('MODIS', cm, C.M), ds('VIIRS', cv, C.V), hd] }); charts.time.update();
  drawAnomalies(days, an);
  
  const bin = arr => { const b = [0, 0, 0, 0, 0]; arr.forEach(c => b[Math.min(4, Math.floor(c / 20))]++); return b; };
  charts.conf.data.datasets = [{ label: 'MODIS', data: bin(m.map(p => p.c)), backgroundColor: C.M }, { label: 'VIIRS', data: bin(v.map(p => p.c)), backgroundColor: C.V }]; charts.conf.update();
  charts.over.data.datasets[0].data = [mo, vo, n]; charts.over.update();
}

// ---- Apply
function regionBbox() { const [s, w, n, e] = REGIONS[$('region').value]; return [w, s, e, n]; }

async function apply() {
  syncOut();
  try {
    if (!raw.length) {
      if (window.APP_CONFIG && APP_CONFIG.apiUrl) {
        try {
          const r = await API.getHotspots({
            bbox: regionBbox(),
            from: $('from').value, to: $('to').value,
            sensors: ['MODIS', 'VIIRS'],
          });
          if (r && r.hotspots && r.hotspots.length) { raw = r.hotspots; status('Live FIRMS data · ' + raw.length + ' detections'); }
        } catch (e) { /* fall through to mock */ }
      }
      if (!raw.length) { raw = loadDemo(); status('Showing demo data (synthetic)'); }
    } else {
      status('Showing ' + raw.length + ' detections');
    }
    view = filtered();
    Persistent.markPersistent(view.m.concat(view.v), {
      days: +$('persistDays').value || 3,
      km: +$('persistKm').value || 1,
    });
    drawMap(); drawStats();
    UrlState.write(collectUrlState());
  } catch (e) { status('Could not load data: ' + e.message, true); }
}

function collectUrlState() {
  return {
    region: $('region').value,
    from: $('from').value, to: $('to').value,
    dist: $('dist').value, hours: $('hours').value,
    sensor: document.querySelector('[name=sensor]:checked').value,
    persistDays: $('persistDays').value, persistKm: $('persistKm').value,
    hidePersist: $('hidePersist').checked ? '1' : '',
  };
}
function applyUrlState(s) {
  if (s.region) $('region').value = s.region;
  if (s.from) $('from').value = s.from;
  if (s.to) $('to').value = s.to;
  if (s.dist) $('dist').value = s.dist;
  if (s.hours) $('hours').value = s.hours;
  if (s.sensor) { const r = document.querySelector(`[name=sensor][value="${s.sensor}"]`); if (r) r.checked = true; }
  if (s.persistDays) $('persistDays').value = s.persistDays;
  if (s.persistKm) $('persistKm').value = s.persistKm;
  if (s.hidePersist === '1') $('hidePersist').checked = true;
}
$('controls').addEventListener('submit', e => { e.preventDefault(); apply(); });
document.querySelectorAll('[name=sensor]').forEach(r => r.addEventListener('change', drawMap));
['dist', 'hours'].forEach(id => $(id).addEventListener('input', () => { syncOut(); if (raw.length) { view = filtered(); drawMap(); drawStats(); } }));
$('reset').addEventListener('click', () => setTimeout(() => {
  $('preset').value = '30'; setDates();
  $('persistDays').value = 3; $('persistKm').value = 1; $('hidePersist').checked = false;
  history.replaceState(null, '', location.pathname);
  apply();
}));
$('region').addEventListener('change', () => { const [s, w, n, e] = REGIONS[$('region').value]; map.fitBounds([[s, w], [n, e]]); });

$('csv').addEventListener('click', () => {
  Exporter.exportPoints({ m: view.m, v: view.v, pairs: view.pairs, hidePersistent: $('hidePersist').checked });
});
$('csvClusters').addEventListener('click', () => {
  Exporter.exportClusters({ pairs: view.pairs, hidePersistent: $('hidePersist').checked });
});

['persistDays', 'persistKm'].forEach(id => $(id).addEventListener('input', () => {
  syncOut();
  if (raw.length) { view = filtered();
    Persistent.markPersistent(view.m.concat(view.v), { days: +$('persistDays').value, km: +$('persistKm').value });
    drawMap(); drawStats(); }
}));
$('hidePersist').addEventListener('change', () => { drawMap(); drawStats(); });

// init with URL state
const initState = UrlState.read();
if (Object.keys(initState).length) { applyUrlState(initState); }
apply().catch(e => status('Init failed: ' + e.message, true));
})();